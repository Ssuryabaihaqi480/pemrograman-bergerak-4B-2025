package com.example.latihan_layout_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
