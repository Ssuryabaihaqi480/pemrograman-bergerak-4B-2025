package com.example.latihan_penggunaan_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
